

<?php $__env->startSection('title', 'Semester 1'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full h-screen flex flex-col items-center justify-center bg-yellow-400 text-black p-4">
    <!-- Joy Emoticon -->
    <svg width="1440" height="1024" viewBox="0 0 1440 1024" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M420.798 182C527.654 182 614.289 286.257 614.289 414.867C614.289 543.459 527.654 647.715 420.798 647.715C313.942 647.715 227.307 543.459 227.307 414.867C227.307 286.257 313.942 182 420.798 182Z" fill="#3A2018"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M507.39 261.238C555.178 276.63 583.543 335.79 570.736 393.281C557.93 450.786 508.802 484.941 460.999 469.53C413.225 454.084 384.875 394.997 397.667 337.487C410.459 279.962 459.587 245.86 507.39 261.238Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M334.549 416.449C362.158 425.352 378.529 459.486 371.128 492.663C363.726 525.867 335.362 545.603 307.767 536.681C280.186 527.77 263.815 493.657 271.202 460.446C278.589 427.241 306.968 407.54 334.549 416.449Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M577.239 750.944C571.535 743.41 571.991 731.686 578.266 724.84C584.541 717.975 594.238 718.506 599.942 726.074C615.786 746.997 633.712 764.312 653.05 777.766C671.732 790.739 691.725 800.124 712.389 805.709C735.435 799.769 755.471 789.712 772.427 776.687C791.194 762.214 806.183 744.04 817.249 723.707C821.898 715.161 831.424 712.774 838.526 718.351C845.628 723.929 847.625 735.413 842.976 743.973C829.627 768.482 811.559 790.376 789.013 807.78C768.177 823.828 743.549 835.995 715.327 842.685V842.673C713.416 843.102 711.377 843.135 709.337 842.618C684.252 836.39 660.095 825.283 637.662 809.723C615.615 794.379 595.194 774.696 577.239 750.944Z" fill="#3A2018"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M1012.07 182C1118.92 182 1205.54 286.257 1205.54 414.867C1205.54 543.459 1118.92 647.715 1012.07 647.715C905.21 647.715 818.561 543.459 818.561 414.867C818.561 286.257 905.21 182 1012.07 182Z" fill="#3A2018"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M1098.64 261.238C1146.45 276.63 1174.8 335.79 1161.99 393.281C1149.18 450.786 1100.06 484.941 1052.27 469.53C1004.48 454.084 976.129 394.997 988.921 337.487C1001.74 279.962 1050.84 245.86 1098.64 261.238Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M925.817 416.449C953.398 425.352 969.769 459.486 962.396 492.663C954.995 525.867 926.63 545.603 899.036 536.681C871.441 527.77 855.069 493.657 862.456 460.446C869.858 427.241 898.223 407.54 925.817 416.449Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M351.005 654.306C518.085 660.453 514.72 793.951 347.64 787.857C180.56 781.751 183.925 648.212 351.005 654.306Z" fill="#DC98AB"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M1089.99 654.306C922.922 660.453 926.287 793.951 1093.37 787.857C1260.45 781.751 1257.07 648.212 1089.99 654.306Z" fill="#DC98AB"/>
</svg>

    <h1 class="text-5xl font-black mt-8 uppercase">Semester 1</h1>
    <a href="/" class="mt-8 px-6 py-3 bg-pink-400 text-black font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Back to Home</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\praktikum_w4\resources\views/pages/page1.blade.php ENDPATH**/ ?>