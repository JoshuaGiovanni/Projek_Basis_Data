<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('client.dashboard')); ?>" class="text-sm text-gray-500">← Back to dashboard</a>

<div class="mx-auto mt-4 max-w-2xl rounded-xl border bg-white p-6">
    <h2 class="text-xl font-semibold">Order Brief for Order #<?php echo e($order->order_id); ?></h2>
    <form class="mt-4 grid gap-4" method="POST" action="<?php echo e(route('orders.brief.submit', $order)); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block text-sm font-medium">Project Description</label>
            <textarea name="project_description" rows="5" class="mt-1 w-full rounded-md border px-3 py-2"><?php echo e(old('project_description', optional($brief)->project_description)); ?></textarea>
        </div>
        <div>
            <label class="block text-sm font-medium">Attachments URL (e.g., Google Drive link)</label>
            <input name="attachments_url" class="mt-1 w-full rounded-md border px-3 py-2" value="<?php echo e(old('attachments_url', optional($brief)->attachments_url)); ?>" />
        </div>
        <div class="flex justify-end">
            <button type="submit" class="rounded-md bg-gray-900 px-4 py-2 text-white">Save Brief</button>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/orders/brief.blade.php ENDPATH**/ ?>