

<?php $__env->startSection('title', 'Emotions of College Semesters'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full h-screen flex flex-col items-center justify-center bg-[#F9A8D4] text-black p-4">
    <h1 class="text-6xl md:text-8xl font-black text-center uppercase tracking-tighter">
        Emotions of College Semesters
    </h1>
    <nav class="mt-12 flex flex-wrap justify-center gap-4">
        <a href="/semester-1" class="px-6 py-3 bg-yellow-400 text-black font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Semester 1</a>
        <a href="/semester-2" class="px-6 py-3 bg-sky-400 text-black font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Semester 2</a>
        <a href="/semester-3" class="px-6 py-3 bg-orange-400 text-black font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Semester 3</a>
        <a href="/semester-4" class="px-6 py-3 bg-slate-400 text-black font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Semester 4</a>
        <a href="/semester-5" class="px-6 py-3 bg-indigo-500 text-white font-bold rounded-lg border-2 border-black shadow-[5px_5px_0px_0px_#000] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">Semester 5</a>
    </nav>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/pages/home.blade.php ENDPATH**/ ?>