<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('home')); ?>" class="text-sm text-gray-500">← Back to Home</a>

<div class="mx-auto mt-6 max-w-2xl rounded-2xl border bg-white p-10 shadow-sm">
    <h2 class="text-2xl font-semibold">Create your account</h2>
    <p class="text-gray-600">Choose your role to get the right experience.</p>

    <form class="mt-6 grid gap-6 md:grid-cols-2" method="POST" action="<?php echo e(route('register.post')); ?>">
        <?php echo csrf_field(); ?>
        <div class="space-y-3">
            <div>
                <label class="block text-sm font-medium">Full Name</label>
                <input name="name" type="text" class="mt-1 w-full rounded-md border px-3 py-2" placeholder="Jane Doe" value="<?php echo e(old('name')); ?>" required />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-1 text-sm text-red-600"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Email</label>
                <input name="email" type="email" class="mt-1 w-full rounded-md border px-3 py-2" placeholder="jane@example.com" value="<?php echo e(old('email')); ?>" required />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-1 text-sm text-red-600"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Password</label>
                <input name="password" type="password" class="mt-1 w-full rounded-md border px-3 py-2" placeholder="••••••••" required />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-1 text-sm text-red-600"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Role</label>
                <select name="role" class="mt-1 w-full rounded-md border px-3 py-2" required>
                    <option value="CLIENT" <?php echo e(old('role') === 'CLIENT' ? 'selected' : ''); ?>>Client</option>
                    <option value="ANALYST" <?php echo e(old('role') === 'ANALYST' ? 'selected' : ''); ?>>Analyst</option>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-1 text-sm text-red-600"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Phone (optional)</label>
                <input name="phone" type="text" class="mt-1 w-full rounded-md border px-3 py-2" placeholder="+62..." value="<?php echo e(old('phone')); ?>" />
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-1 text-sm text-red-600"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="w-full rounded-md bg-gray-900 py-2 text-white">Create Account</button>
        </div>

        <div class="rounded-lg border bg-gray-50 p-4 text-sm text-gray-600">
            <div class="font-medium mb-2">What happens next?</div>
            <ul class="list-disc list-inside space-y-1">
                <li>We create your account securely</li>
                <li>Analysts will be taken to profile setup</li>
                <li>Clients can start browsing analysts</li>
            </ul>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/auth/register.blade.php ENDPATH**/ ?>