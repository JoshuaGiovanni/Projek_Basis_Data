

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('analyst.dashboard')); ?>" class="text-sm text-gray-500">← Back to dashboard</a>

<div class="mx-auto mt-4 max-w-3xl rounded-xl border bg-white p-6">
    <h2 class="text-xl font-semibold">Order Brief for Order #<?php echo e($order->order_id); ?></h2>
    <?php if($brief): ?>
    <div class="mt-4">
        <div class="text-sm text-gray-600">Submitted at: <?php echo e($brief->submitted_at); ?></div>
        <div class="mt-2 whitespace-pre-line"><?php echo e($brief->project_description); ?></div>
        <?php if($brief->attachments_url): ?>
        <div class="mt-3">
            
            <a class="text-blue-600 underline" href="<?php echo e(Illuminate\Support\Str::startsWith($brief->attachments_url, ['http://', 'https://']) ? $brief->attachments_url : 'https://' . $brief->attachments_url); ?>" target="_blank">View Attachments</a>
        </div>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="mt-4 text-sm text-gray-600">No brief submitted.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/orders/brief_readonly.blade.php ENDPATH**/ ?>