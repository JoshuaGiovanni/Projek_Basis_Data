<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-semibold">Analyst Dashboard</h2>

<div class="mt-4 grid gap-6 md:grid-cols-3">
    <section class="rounded-xl border bg-white p-4 md:col-span-2">
        <div class="flex items-center justify-between">
            <h3 class="font-semibold">Order Offers</h3>
        </div>
        <div class="mt-3 divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="py-3">
                <div class="text-sm text-gray-600">Service #<?php echo e($order->service_id); ?> · <?php echo e($order->status); ?></div>
                <div class="font-medium">Final amount: $<?php echo e(number_format($order->final_amount, 2)); ?></div>
                <?php $brief = \App\Models\OrderBrief::where('order_id', $order->order_id)->first(); ?>
                <?php if($brief): ?>
                <a href="<?php echo e(route('analyst.order.brief', $order)); ?>" class="mt-2 inline-flex rounded-md bg-gray-900 px-3 py-1 text-white">View Order Brief</a>
                <?php endif; ?>
                <?php if($order->status === 'PENDING'): ?>
                <div class="mt-2 flex gap-2">
                    <form method="POST" action="<?php echo e(route('orders.accept', $order)); ?>"><?php echo csrf_field(); ?><button class="rounded-md bg-green-600 px-3 py-1 text-white">Accept</button></form>
                    <form method="POST" action="<?php echo e(route('orders.reject', $order)); ?>"><?php echo csrf_field(); ?><button class="rounded-md bg-red-600 px-3 py-1 text-white">Reject</button></form>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-sm text-gray-600">No offers yet.</div>
            <?php endif; ?>
        </div>
    </section>

    <section class="rounded-xl border bg-white p-4">
        <h3 class="font-semibold">Quick Actions</h3>
        <div class="mt-3 grid gap-2">
            <a href="<?php echo e(route('analysts.profile')); ?>" class="rounded-md bg-gray-900 px-3 py-2 text-white text-center">Edit Profile</a>
            <a href="<?php echo e(route('analyst.service.new')); ?>" class="rounded-md bg-green-600 px-3 py-2 text-white text-center">Post a Service</a>
        </div>
    </section>

    <section class="rounded-xl border bg-white p-4 md:col-span-3">
        <h3 class="font-semibold">Your Services</h3>
        <div class="mt-3 grid gap-4 md:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="rounded-lg border p-3">
                <div class="font-medium"><?php echo e($service->title); ?></div>
                <div class="text-sm text-gray-600"><?php echo e($service->category); ?></div>
                <div class="text-sm">$<?php echo e(number_format($service->price_min, 2)); ?> - $<?php echo e(number_format($service->price_max, 2)); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-sm text-gray-600">No services yet.</div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/analysts/dashboard.blade.php ENDPATH**/ ?>