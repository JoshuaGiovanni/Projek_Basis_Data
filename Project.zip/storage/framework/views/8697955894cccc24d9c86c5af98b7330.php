

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-semibold">Your Orders</h2>

<div class="mt-4 grid gap-4">
    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="rounded-lg border bg-white p-4">
        <div class="flex items-center justify-between">
            <div class="font-medium">Order #<?php echo e($order->order_id); ?></div>
            <div class="text-sm">Status: <?php echo e($order->status); ?></div>
        </div>
        <div class="text-sm text-gray-600">Service ID: <?php echo e($order->service_id); ?> · Final: $<?php echo e(number_format($order->final_amount, 2)); ?></div>
        <?php if($order->status === 'IN_PROGRESS'): ?>
        <a href="<?php echo e(route('orders.brief', $order)); ?>" class="mt-2 inline-flex rounded-md bg-gray-900 px-3 py-2 text-white">Send Order Brief</a>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="text-sm text-gray-600">No orders yet.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/clients/dashboard.blade.php ENDPATH**/ ?>