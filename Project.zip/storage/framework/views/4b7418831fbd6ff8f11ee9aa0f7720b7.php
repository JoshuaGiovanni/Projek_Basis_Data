<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('analysts.index')); ?>" class="text-sm text-gray-500">← Back to list</a>

<div class="mt-4 rounded-xl border bg-white p-6">
    <div class="flex items-start justify-between">
        <div>
            <div class="text-2xl font-semibold"><?php echo e($profile->full_name); ?></div>
            <div class="text-sm text-gray-600"><?php echo e($profile->status); ?></div>
        </div>
        <span class="rounded-full bg-gray-100 px-2 py-1 text-xs">Rating: <?php echo e(number_format($profile->average_rating, 1)); ?></span>
    </div>
    <div class="mt-3 text-gray-700"><?php echo e($profile->description); ?></div>
</div>

<h3 class="mt-6 text-xl font-semibold">Services</h3>
<div class="mt-2 grid gap-4 md:grid-cols-2">
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="rounded-lg border bg-white p-4 h-full flex flex-col">
        <div class="font-medium"><?php echo e($service->title); ?></div>
        <div class="text-sm text-gray-600"><?php echo e($service->category ?? 'Uncategorized'); ?></div>
        <div class="mt-2 text-sm"><?php echo e($service->description); ?></div>
        <div class="mt-2 font-semibold">$<?php echo e(number_format($service->price_min, 2)); ?> - $<?php echo e(number_format($service->price_max, 2)); ?></div>
        <form class="mt-auto pt-3" method="POST" action="<?php echo e(route('orders.book', $service->service_id)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="rounded-md bg-green-600 px-3 py-2 text-white">Book</button>
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projek\resources\views/analysts/show.blade.php ENDPATH**/ ?>